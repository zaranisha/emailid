package modifierimport;

import Phase1.*;

public class accessimport extends Project_Assisted2 {
	public static void main(String[] args) {
		accessimport obj = new accessimport ();   
	       obj.display(); 
	       System.out.println(" ");
	        obj.display1();  
	}

}
